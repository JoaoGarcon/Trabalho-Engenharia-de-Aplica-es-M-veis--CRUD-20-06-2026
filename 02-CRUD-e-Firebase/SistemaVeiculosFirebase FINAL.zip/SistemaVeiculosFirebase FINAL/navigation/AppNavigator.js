import React from 'react';

import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import LoginScreen from '../screens/LoginScreen';
import RegisterScreen from '../screens/RegisterScreen';
import ProfileScreen from '../screens/ProfileScreen';
import VehiclesScreen from '../screens/VehiclesScreen';
import VehicleFormScreen from '../screens/VehicleFormScreen';

const Stack = createNativeStackNavigator();

export default function AppNavigator() {

  return (
    <NavigationContainer>

      <Stack.Navigator>

        <Stack.Screen
          name="Login"
          component={LoginScreen}
        />

        <Stack.Screen
          name="CadastroUsuario"
          component={RegisterScreen}
          options={{ title: 'Cadastro de Usuário' }}
        />

        <Stack.Screen
          name="Perfil"
          component={ProfileScreen}
        />

        <Stack.Screen
          name="Veiculos"
          component={VehiclesScreen}
        />

        <Stack.Screen
          name="CadastroVeiculo"
          component={VehicleFormScreen}
          options={{ title: 'Cadastro de Veículo' }}
        />

      </Stack.Navigator>

    </NavigationContainer>
  );
}