import { initializeApp } from 'firebase/app';

import {
  getAuth
} from 'firebase/auth';

import {
  getFirestore
} from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyDfgK6wqwsJfaFuSlWGDNHJ5-6Jqpr6gk8",
  authDomain: "sistemaveiculosfirebase.firebaseapp.com",
  projectId: "sistemaveiculosfirebase",
  storageBucket: "sistemaveiculosfirebase.firebasestorage.app",
  messagingSenderId: "804205350211",
  appId: "1:804205350211:web:1bd7c7a332c08499b8b3f6"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);

export default app;