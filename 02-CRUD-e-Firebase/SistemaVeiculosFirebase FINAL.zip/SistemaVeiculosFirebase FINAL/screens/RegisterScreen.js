import React, { useState } from 'react';
import { View, StyleSheet, Alert } from 'react-native';
import { TextInput, Button, Card, Text } from 'react-native-paper';

import { auth } from '../firebase/config';

import {
  createUserWithEmailAndPassword,
  updateProfile
} from 'firebase/auth';

export default function RegisterScreen({ navigation }) {

  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [confirmarSenha, setConfirmarSenha] = useState('');

  const cadastrarUsuario = async () => {

    if (!nome || !email || !senha || !confirmarSenha) {
      Alert.alert('Erro', 'Preencha todos os campos.');
      return;
    }

    if (senha !== confirmarSenha) {
      Alert.alert('Erro', 'As senhas não coincidem.');
      return;
    }

    try {

      const userCredential =
        await createUserWithEmailAndPassword(
          auth,
          email,
          senha
        );

      await updateProfile(
        userCredential.user,
        {
          displayName: nome
        }
      );

      Alert.alert(
        'Sucesso',
        'Usuário cadastrado com sucesso.'
      );

      navigation.navigate('Login');

    } catch (error) {

      Alert.alert(
        'Erro no Cadastro',
        error.message
      );

    }
  };

  return (
    <View style={styles.container}>
      <Card>
        <Card.Content>

          <Text
            variant="headlineSmall"
            style={styles.titulo}
          >
            Cadastro de Usuário
          </Text>

          <TextInput
            label="Nome"
            value={nome}
            onChangeText={setNome}
            style={styles.input}
          />

          <TextInput
            label="E-mail"
            value={email}
            onChangeText={setEmail}
            style={styles.input}
            autoCapitalize="none"
          />

          <TextInput
            label="Senha"
            value={senha}
            onChangeText={setSenha}
            secureTextEntry
            style={styles.input}
          />

          <TextInput
            label="Confirmar Senha"
            value={confirmarSenha}
            onChangeText={setConfirmarSenha}
            secureTextEntry
            style={styles.input}
          />

          <Button
            mode="contained"
            style={styles.botao}
            onPress={cadastrarUsuario}
          >
            Cadastrar
          </Button>

          <Button
            onPress={() => navigation.goBack()}
          >
            Voltar
          </Button>

        </Card.Content>
      </Card>
    </View>
  );
}

const styles = StyleSheet.create({
  container:{
    flex:1,
    justifyContent:'center',
    padding:20
  },
  titulo:{
    marginBottom:20,
    textAlign:'center'
  },
  input:{
    marginBottom:10
  },
  botao:{
    marginTop:10
  }
});