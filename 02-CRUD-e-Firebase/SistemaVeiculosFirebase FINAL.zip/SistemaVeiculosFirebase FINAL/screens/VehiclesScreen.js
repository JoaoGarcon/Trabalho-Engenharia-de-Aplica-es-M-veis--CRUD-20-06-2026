import React, { useEffect, useState } from 'react';

import {
  View,
  FlatList,
  StyleSheet,
  Alert
} from 'react-native';

import {
  Card,
  Text,
  Button
} from 'react-native-paper';

import { auth, db } from '../firebase/config';

import {
  collection,
  query,
  where,
  onSnapshot,
  deleteDoc,
  doc
} from 'firebase/firestore';

export default function VehiclesScreen({ navigation }) {

  const [veiculos, setVeiculos] = useState([]);

  useEffect(() => {

    const q = query(
      collection(db, 'veiculos'),
      where(
        'usuarioId',
        '==',
        auth.currentUser.uid
      )
    );

    const unsubscribe = onSnapshot(q, snapshot => {

      const lista = [];

      snapshot.forEach(documento => {

        lista.push({
          id: documento.id,
          ...documento.data()
        });

      });

      setVeiculos(lista);

    });

    return () => unsubscribe();

  }, []);

  const excluirVeiculo = (id) => {

    Alert.alert(
      'Excluir Veículo',
      'Deseja realmente excluir este veículo?',
      [
        {
          text: 'Cancelar',
          style: 'cancel'
        },
        {
          text: 'Excluir',
          style: 'destructive',
          onPress: async () => {

            try {

              await deleteDoc(
                doc(db, 'veiculos', id)
              );

            } catch (error) {

              Alert.alert(
                'Erro',
                error.message
              );

            }

          }
        }
      ]
    );

  };

  const renderItem = ({ item }) => (

    <Card style={styles.card}>
      <Card.Content>

        <Text variant="titleMedium">
          {item.marca} - {item.modelo}
        </Text>

        <Text>Ano: {item.ano}</Text>
        <Text>Placa: {item.placa}</Text>
        <Text>Chassi: {item.chassi}</Text>

        <Button
          mode="outlined"
          style={styles.botao}
          onPress={() =>
            navigation.navigate(
              'CadastroVeiculo',
              { veiculo: item }
            )
          }
        >
          Editar
        </Button>

        <Button
          mode="contained-tonal"
          style={styles.botao}
          onPress={() =>
            excluirVeiculo(item.id)
          }
        >
          Excluir
        </Button>

      </Card.Content>
    </Card>

  );

  return (
    <View style={styles.container}>

      <Button
        mode="contained"
        style={styles.novoBotao}
        onPress={() =>
          navigation.navigate('CadastroVeiculo')
        }
      >
        Novo Veículo
      </Button>

      <FlatList
        data={veiculos}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
      />

    </View>
  );
}

const styles = StyleSheet.create({
  container:{
    flex:1,
    padding:15
  },
  novoBotao:{
    marginBottom:15
  },
  card:{
    marginBottom:10
  },
  botao:{
    marginTop:10
  }
});