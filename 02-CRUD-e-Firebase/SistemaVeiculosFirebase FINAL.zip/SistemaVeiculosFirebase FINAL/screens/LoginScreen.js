import React, { useState } from 'react';

import {
  View,
  StyleSheet,
  Alert
} from 'react-native';

import {
  Card,
  Text,
  TextInput,
  Button
} from 'react-native-paper';

import { auth } from '../firebase/config';

import {
  signInWithEmailAndPassword
} from 'firebase/auth';

export default function LoginScreen({ navigation }) {

  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');

  const fazerLogin = async () => {

    if (!email || !senha) {
      Alert.alert('Erro', 'Preencha todos os campos.');
      return;
    }

    try {

      await signInWithEmailAndPassword(
        auth,
        email,
        senha
      );

      navigation.navigate('Perfil');

    } catch (error) {

      Alert.alert(
        'Erro no Login',
        error.message
      );

    }
  };

  return (
    <View style={styles.container}>

      <Card>
        <Card.Content>

          <Text
            variant="headlineMedium"
            style={styles.titulo}
          >
            Sistema de Veículos
          </Text>

          <TextInput
            label="E-mail"
            value={email}
            onChangeText={setEmail}
            style={styles.input}
            autoCapitalize="none"
          />

          <TextInput
            label="Senha"
            value={senha}
            onChangeText={setSenha}
            secureTextEntry
            style={styles.input}
          />

          <Button
            mode="contained"
            style={styles.botao}
            onPress={fazerLogin}
          >
            Entrar
          </Button>

          <Button
            mode="text"
            onPress={() => navigation.navigate('CadastroUsuario')}
          >
            Cadastrar Usuário
          </Button>

        </Card.Content>
      </Card>

    </View>
  );
}

const styles = StyleSheet.create({
  container:{
    flex:1,
    justifyContent:'center',
    padding:20
  },
  titulo:{
    textAlign:'center',
    marginBottom:20
  },
  input:{
    marginBottom:10
  },
  botao:{
    marginTop:10
  }
});