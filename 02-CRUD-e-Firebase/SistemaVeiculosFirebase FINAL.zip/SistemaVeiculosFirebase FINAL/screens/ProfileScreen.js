import React from 'react';
import {
  View,
  StyleSheet,
  Alert
} from 'react-native';

import {
  Card,
  Text,
  Button
} from 'react-native-paper';

import { auth } from '../firebase/config';

import {
  signOut,
  deleteUser
} from 'firebase/auth';

export default function ProfileScreen({ navigation }) {

  const usuario = auth.currentUser;

  const fazerLogout = async () => {

    try {

      await signOut(auth);

      navigation.reset({
        index: 0,
        routes: [{ name: 'Login' }]
      });

    } catch (error) {

      Alert.alert('Erro', error.message);

    }
  };

  const excluirConta = () => {

    Alert.alert(
      'Excluir Conta',
      'Deseja realmente excluir sua conta?',
      [
        {
          text: 'Cancelar',
          style: 'cancel'
        },
        {
          text: 'Excluir',
          style: 'destructive',
          onPress: async () => {

            try {

              await deleteUser(auth.currentUser);

              navigation.reset({
                index: 0,
                routes: [{ name: 'Login' }]
              });

            } catch (error) {

              Alert.alert('Erro', error.message);

            }

          }
        }
      ]
    );
  };

  return (
    <View style={styles.container}>
      <Card>
        <Card.Content>

          <Text variant="headlineSmall" style={styles.titulo}>
            Perfil do Usuário
          </Text>

          <Text style={styles.texto}>
            Nome: {usuario?.displayName || 'Não informado'}
          </Text>

          <Text style={styles.texto}>
            E-mail: {usuario?.email}
          </Text>

          <Button
            mode="contained"
            style={styles.botao}
            onPress={() => navigation.navigate('Veiculos')}
          >
            Meus Veículos
          </Button>

          <Button
            mode="outlined"
            style={styles.botao}
            onPress={fazerLogout}
          >
            Logout
          </Button>

          <Button
            mode="contained-tonal"
            style={styles.botao}
            onPress={excluirConta}
          >
            Excluir Conta
          </Button>

        </Card.Content>
      </Card>
    </View>
  );
}

const styles = StyleSheet.create({
  container:{
    flex:1,
    justifyContent:'center',
    padding:20
  },
  titulo:{
    textAlign:'center',
    marginBottom:20
  },
  texto:{
    marginBottom:10,
    fontSize:16
  },
  botao:{
    marginTop:10
  }
});