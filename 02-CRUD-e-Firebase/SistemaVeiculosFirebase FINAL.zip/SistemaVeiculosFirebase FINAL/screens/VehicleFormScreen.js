import React, { useState } from 'react';

import {
  View,
  StyleSheet,
  Alert
} from 'react-native';

import {
  TextInput,
  Button,
  Card,
  Text
} from 'react-native-paper';

import { auth, db } from '../firebase/config';

import {
  collection,
  addDoc,
  updateDoc,
  doc
} from 'firebase/firestore';

export default function VehicleFormScreen({
  navigation,
  route
}) {

  const veiculo = route?.params?.veiculo;

  const [marca, setMarca] = useState(
    veiculo?.marca || ''
  );

  const [modelo, setModelo] = useState(
    veiculo?.modelo || ''
  );

  const [ano, setAno] = useState(
    veiculo?.ano || ''
  );

  const [placa, setPlaca] = useState(
    veiculo?.placa || ''
  );

  const [chassi, setChassi] = useState(
    veiculo?.chassi || ''
  );

  const salvarVeiculo = async () => {

    if (
      !marca ||
      !modelo ||
      !ano ||
      !placa ||
      !chassi
    ) {
      Alert.alert(
        'Erro',
        'Preencha todos os campos.'
      );
      return;
    }

    const dados = {
      marca,
      modelo,
      ano,
      placa,
      chassi,
      usuarioId: auth.currentUser.uid
    };

    try {

      if (veiculo) {

        await updateDoc(
          doc(db, 'veiculos', veiculo.id),
          dados
        );

        Alert.alert(
          'Sucesso',
          'Veículo atualizado.'
        );

      } else {

        await addDoc(
          collection(db, 'veiculos'),
          dados
        );

        Alert.alert(
          'Sucesso',
          'Veículo cadastrado.'
        );

      }

      navigation.goBack();

    } catch (error) {

      Alert.alert(
        'Erro',
        error.message
      );

    }
  };

  return (
    <View style={styles.container}>

      <Card>
        <Card.Content>

          <Text
            variant="headlineSmall"
            style={styles.titulo}
          >
            {veiculo
              ? 'Editar Veículo'
              : 'Cadastro de Veículo'}
          </Text>

          <TextInput
            label="Marca"
            value={marca}
            onChangeText={setMarca}
            style={styles.input}
          />

          <TextInput
            label="Modelo"
            value={modelo}
            onChangeText={setModelo}
            style={styles.input}
          />

          <TextInput
            label="Ano"
            value={ano}
            onChangeText={setAno}
            style={styles.input}
            keyboardType="numeric"
          />

          <TextInput
            label="Placa"
            value={placa}
            onChangeText={setPlaca}
            style={styles.input}
          />

          <TextInput
            label="Número do Chassi"
            value={chassi}
            onChangeText={setChassi}
            style={styles.input}
          />

          <Button
            mode="contained"
            onPress={salvarVeiculo}
          >
            Salvar
          </Button>

        </Card.Content>
      </Card>

    </View>
  );
}

const styles = StyleSheet.create({
  container:{
    flex:1,
    justifyContent:'center',
    padding:20
  },
  titulo:{
    textAlign:'center',
    marginBottom:20
  },
  input:{
    marginBottom:10
  }
});