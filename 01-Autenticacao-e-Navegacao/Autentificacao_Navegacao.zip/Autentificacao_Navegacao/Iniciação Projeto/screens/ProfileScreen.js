import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Card, Text, Button } from 'react-native-paper';

export default function ProfileScreen({ navigation }) {

  return (
    <View style={styles.container}>

      <Card>
        <Card.Content>

          <Text variant="headlineSmall">
            Perfil do Usuário
          </Text>

          <Text>
            Nome: Usuário Teste
          </Text>

          <Text>
            E-mail: usuario@email.com
          </Text>

          <Button
            mode="contained"
            style={styles.botao}
          >
            Editar Perfil
          </Button>

          <Button
            mode="outlined"
            style={styles.botao}
          >
            Excluir Usuário
          </Button>

          <Button
            mode="contained"
            style={styles.botao}
            onPress={() => navigation.navigate('Veiculos')}
          >
            Meus Veículos
          </Button>

        </Card.Content>
      </Card>

    </View>
  );
}

const styles = StyleSheet.create({
  container:{
    flex:1,
    justifyContent:'center',
    padding:20
  },
  botao:{
    marginTop:10
  }
});