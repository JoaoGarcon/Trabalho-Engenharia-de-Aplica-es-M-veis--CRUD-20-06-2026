import React, { useState } from 'react';

import {
  View,
  StyleSheet
} from 'react-native';

import {
  Card,
  Text,
  TextInput,
  Button
} from 'react-native-paper';

export default function LoginScreen({ navigation }) {

  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');

  return (
    <View style={styles.container}>

      <Card>
        <Card.Content>

          <Text
            variant="headlineMedium"
            style={styles.titulo}
          >
            Sistema de Veículos
          </Text>

          <TextInput
            label="E-mail"
            value={email}
            onChangeText={setEmail}
            style={styles.input}
          />

          <TextInput
            label="Senha"
            value={senha}
            onChangeText={setSenha}
            secureTextEntry
            style={styles.input}
          />

          <Button
            mode="contained"
            style={styles.botao}
            onPress={() => navigation.navigate('Perfil')}
          >
            Entrar
          </Button>

          <Button
            mode="text"
            onPress={() => navigation.navigate('CadastroUsuario')}
          >
            Cadastrar Usuário
          </Button>

        </Card.Content>
      </Card>

    </View>
  );
}

const styles = StyleSheet.create({
  container:{
    flex:1,
    justifyContent:'center',
    padding:20
  },
  titulo:{
    textAlign:'center',
    marginBottom:20
  },
  input:{
    marginBottom:10
  },
  botao:{
    marginTop:10
  }
});