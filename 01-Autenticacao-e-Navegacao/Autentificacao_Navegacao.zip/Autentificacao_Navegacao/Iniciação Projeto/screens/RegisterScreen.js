import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';
import { TextInput, Button, Card, Text } from 'react-native-paper';

export default function RegisterScreen({ navigation }) {

  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [confirmarSenha, setConfirmarSenha] = useState('');

  return (
    <View style={styles.container}>
      <Card>
        <Card.Content>

          <Text
            variant="headlineSmall"
            style={styles.titulo}
          >
            Cadastro de Usuário
          </Text>

          <TextInput
            label="Nome"
            value={nome}
            onChangeText={setNome}
            style={styles.input}
          />

          <TextInput
            label="E-mail"
            value={email}
            onChangeText={setEmail}
            style={styles.input}
          />

          <TextInput
            label="Senha"
            value={senha}
            onChangeText={setSenha}
            secureTextEntry
            style={styles.input}
          />

          <TextInput
            label="Confirmar Senha"
            value={confirmarSenha}
            onChangeText={setConfirmarSenha}
            secureTextEntry
            style={styles.input}
          />

         <Button
  mode="contained"
  style={styles.botao}
  onPress={() => navigation.navigate('Login')}
>
  Cadastrar
</Button>

          <Button
            onPress={() => navigation.goBack()}
          >
            Voltar
          </Button>

        </Card.Content>
      </Card>
    </View>
  );
}

const styles = StyleSheet.create({
  container:{
    flex:1,
    justifyContent:'center',
    padding:20
  },
  titulo:{
    marginBottom:20,
    textAlign:'center'
  },
  input:{
    marginBottom:10
  },
  botao:{
    marginTop:10
  }
});