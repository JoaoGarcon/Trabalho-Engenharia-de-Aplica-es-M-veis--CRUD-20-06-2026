import React from 'react';
import { View, FlatList, StyleSheet } from 'react-native';
import { Card, Text, Button } from 'react-native-paper';

export default function VehiclesScreen({ navigation }) {

  const veiculos = [
    {
      id:'1',
      marca:'Toyota',
      modelo:'Corolla',
      ano:'2020',
      placa:'ABC1D23'
    },
    {
      id:'2',
      marca:'Honda',
      modelo:'Civic',
      ano:'2019',
      placa:'XYZ9K88'
    }
  ];

  return (
    <View style={styles.container}>

      <Button
        mode="contained"
        onPress={() =>
          navigation.navigate('CadastroVeiculo')
        }
      >
        Novo Veículo
      </Button>

      <FlatList
        data={veiculos}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (

          <Card style={styles.card}>
            <Card.Content>

              <Text variant="titleMedium">
                {item.marca} {item.modelo}
              </Text>

              <Text>
                Ano: {item.ano}
              </Text>

              <Text>
                Placa: {item.placa}
              </Text>

              <Button>
                Editar
              </Button>

              <Button>
                Excluir
              </Button>

            </Card.Content>
          </Card>

        )}
      />

    </View>
  );
}

const styles = StyleSheet.create({
  container:{
    flex:1,
    padding:15
  },
  card:{
    marginTop:10
  }
});