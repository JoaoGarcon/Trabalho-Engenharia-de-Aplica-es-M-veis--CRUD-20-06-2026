import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';
import { TextInput, Button, Card, Text } from 'react-native-paper';

export default function VehicleFormScreen({ navigation }) {

  const [marca,setMarca] = useState('');
  const [modelo,setModelo] = useState('');
  const [ano,setAno] = useState('');
  const [placa,setPlaca] = useState('');
  const [chassi,setChassi] = useState('');

  return (
    <View style={styles.container}>

      <Card>
        <Card.Content>

          <Text
            variant="headlineSmall"
            style={styles.titulo}
          >
            Cadastro de Veículo
          </Text>

          <TextInput
            label="Marca"
            value={marca}
            onChangeText={setMarca}
            style={styles.input}
          />

          <TextInput
            label="Modelo"
            value={modelo}
            onChangeText={setModelo}
            style={styles.input}
          />

          <TextInput
            label="Ano"
            value={ano}
            onChangeText={setAno}
            style={styles.input}
          />

          <TextInput
            label="Placa"
            value={placa}
            onChangeText={setPlaca}
            style={styles.input}
          />

          <TextInput
            label="Número do Chassi"
            value={chassi}
            onChangeText={setChassi}
            style={styles.input}
          />

          <Button mode="contained">
            Salvar
          </Button>

        </Card.Content>
      </Card>

    </View>
  );
}

const styles = StyleSheet.create({
  container:{
    flex:1,
    justifyContent:'center',
    padding:20
  },
  titulo:{
    textAlign:'center',
    marginBottom:20
  },
  input:{
    marginBottom:10
  }
});