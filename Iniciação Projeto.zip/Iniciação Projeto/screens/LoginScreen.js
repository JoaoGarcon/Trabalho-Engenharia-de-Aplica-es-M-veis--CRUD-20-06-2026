import React from 'react';

import {
  View,
  StyleSheet
} from 'react-native';

import {
  Card,
  Text
} from 'react-native-paper';

export default function LoginScreen() {

  return (
    <View style={styles.container}>
      <Card>
        <Card.Content>

          <Text variant="headlineMedium">
            Sistema de Veículos
          </Text>

        </Card.Content>
      </Card>
    </View>
  );
}

const styles = StyleSheet.create({
  container:{
    flex:1,
    justifyContent:'center',
    padding:20
  }
});